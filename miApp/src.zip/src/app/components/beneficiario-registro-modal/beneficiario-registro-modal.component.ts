import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beneficiario-registro-modal',
  templateUrl: './beneficiario-registro-modal.component.html',
  styleUrls: ['./beneficiario-registro-modal.component.scss'],
})
export class BeneficiarioRegistroModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
