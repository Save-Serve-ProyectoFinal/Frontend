import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-registro-modal',
  templateUrl: './empresa-registro-modal.component.html',
  styleUrls: ['./empresa-registro-modal.component.scss'],
})
export class EmpresaRegistroModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
