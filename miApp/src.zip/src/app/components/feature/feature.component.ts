import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature',
  templateUrl: './feature.component.html',
  styleUrls: ['./feature.component.scss'],
  standalone: false
})
export class FeatureComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
