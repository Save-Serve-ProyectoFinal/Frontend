import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hero-section-articulos',
  templateUrl: './hero-section-articulos.component.html',
  styleUrls: ['./hero-section-articulos.component.scss'],
  standalone:false
})
export class HeroSectionArticulosComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
