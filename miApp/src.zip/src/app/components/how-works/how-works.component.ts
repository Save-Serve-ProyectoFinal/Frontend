import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-works',
  templateUrl: './how-works.component.html',
  styleUrls: ['./how-works.component.scss'],
  standalone: false

})
export class HowWorksComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
