import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impacto',
  templateUrl: './impacto.component.html',
  styleUrls: ['./impacto.component.scss'],
  standalone:false
})
export class ImpactoComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
