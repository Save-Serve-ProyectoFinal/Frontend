import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stadistic',
  templateUrl: './stadistic.component.html',
  styleUrls: ['./stadistic.component.scss'],
  standalone: false
})
export class StadisticComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
