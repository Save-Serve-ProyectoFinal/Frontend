export interface Articulo {
    idArticulo?: number;
    titulo: string;
    subtitulo: string;
    contenido: string;
    imagen: string;
}