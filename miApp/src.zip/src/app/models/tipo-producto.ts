export enum TipoProducto {
    SECO = 'SECO',
    REFRIGERADO = 'REFRIGERADO',
    CONGELADO = 'CONGELADO'
}