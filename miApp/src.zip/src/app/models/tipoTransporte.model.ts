// export interface TipoTransporte {
//     id?: number;
//     tipo: string;
//     productos?: Producto[];
//     transportes?: Transporte[];
// }

//cambios leti

export enum TipoTransporte {
    SECO = 'SECO',
    REFRIGERADO = 'REFRIGERADO',
    CONGELADO = 'CONGELADO'
}