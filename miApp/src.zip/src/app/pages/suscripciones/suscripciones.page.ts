import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suscripciones',
  templateUrl: './suscripciones.page.html',
  styleUrls: ['./suscripciones.page.scss'],
  standalone:false
})
export class SuscripcionesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
