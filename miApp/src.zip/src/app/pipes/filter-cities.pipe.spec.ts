import { FilterCitiesPipe } from './filter-cities.pipe';

describe('FilterCitiesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCitiesPipe();
    expect(pipe).toBeTruthy();
  });
});
